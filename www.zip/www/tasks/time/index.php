﻿<?php

$locations = [
    [
        'city' => 'Москва',
        'country' => 'Россия',
        'tz' => 'Europe/Moscow',
        'locale' => 'ru_RU.utf8',
        'pattern' => 'День: d, EEEE, месяц: LLLL, год: yyyy, HH:mm:ss'
    ],
    [
        'city' => 'Джумла',
        'country' => 'Непал',
        'tz' => 'Asia/Kathmandu',
        'locale' => 'ne_NP.utf8',
        'pattern' => 'EEEE d LLLL yyyy год HH:mm:ss'
    ],
    [
        'city' => 'Тринкомали',
        'country' => 'Шри-Ланка',
        'tz' => 'Asia/Colombo',
        'locale' => 'si_LK.utf8',
        'pattern' => 'EEEE d LLLL yyyy год HH:mm:ss'
    ],
    [
        'city' => 'Ташкент',
        'country' => 'Узбекистан',
        'tz' => 'Asia/Tashkent',
        'locale' => 'uz_UZ.utf8',
        'pattern' => 'EEEE d LLLL yyyy год HH:mm:ss'
    ],
    [
        'city' => 'Канск',
        'country' => 'Россия',
        'tz' => 'Asia/Krasnoyarsk',
        'locale' => 'ru_RU.utf8',
        'pattern' => 'EEEE d LLLL yyyy год HH:mm:ss'
    ]
];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8"/>
    <title>Шаблоны страниц</title>
    <!--[if IE]>
    <script>
        document.createElement('header');
        document.createElement('nav');
        document.createElement('section');
        document.createElement('article');
        document.createElement('aside');
        document.createElement('footer');
    </script>
    <![endif]-->
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
    <style>
        table {
            border-collapse: collapse;
            margin-top: 20px;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
    </style>
</head>
<body>
<div id="main">
    <header>
        <h3>Главная</h3>
        <img class="image" src="img/shapka.jpg" alt=""/>
    </header>
    <nav>
        <ul>
            <li><a href="index.php" class="active">Главная</a></li>
            <li><a href="pages/page_1.htm">Страница 1</a></li>
            <li><a href="pages/page_2.htm">Страница 2</a></li>
        </ul>
    </nav>
    <section>
        <section>
            <article>
                <header>
                    <h2>Время</h2>
                </header>
                <form method="post">
                    <button type="submit" name="show_table">Показать таблицу времени</button>
                </form>
                <?php

                if (isset($_POST['show_table'])) {
                    $data = [];
                    $moscowFormatted = '';
                    $moscowOffset = 0;

                    foreach ($locations as $index => $location) {
                        $dtZone = new DateTimeZone($location['tz']);
                        $dateTime = new DateTime('now', $dtZone);

                        $formatter = new IntlDateFormatter(
                            $location['locale'],
                            IntlDateFormatter::FULL,
                            IntlDateFormatter::LONG,
                            $location['tz'],
                            IntlDateFormatter::GREGORIAN,
                            $location['pattern']
                        );

                        $formatted = $formatter->format($dateTime);
                        $utcOffsetSec = $dateTime->getOffset();
                        $utcOffsetHours = $utcOffsetSec / 3600;
                        $offsetString = sprintf("UTC%+g", $utcOffsetHours);

                        if ($index === 0) {
                            $moscowFormatted = $formatted;
                            $moscowOffset = $utcOffsetSec;
                        } else {
                            $diffSec = $utcOffsetSec - $moscowOffset;
                            $diffHours = $diffSec / 3600;
                            $diffFormatted = sprintf("MSK%+g", $diffHours);

                            $data[] = [
                                'city' => $location['city'],
                                'country' => $location['country'],
                                'local' => $formatted,
                                'utc' => $offsetString,
                                'diff' => $diffFormatted
                            ];
                        }
                    }

                    echo '<table>';
                    $colspan = count($data);
                    echo '<tr>';
                    echo '<td colspan="' . $colspan . '"> <b> Московское время</b><br> ' . htmlspecialchars($moscowFormatted) . '</td>';
                    echo '</tr>';

                    echo '<tr>';
                    foreach ($data as $entry) {
                        echo '<th>' . htmlspecialchars($entry['city']) . '<br>' . htmlspecialchars($entry['country']) . '</th>';
                    }
                    echo '</tr>';

                    echo '<tr>';
                    foreach ($data as $entry) {
                        echo '<td>' . htmlspecialchars($entry['local']) . '</td>';
                    }
                    echo '</tr>';

                    echo '<tr>';
                    foreach ($data as $entry) {
                        echo '<td>' . htmlspecialchars($entry['utc']) . '<br>' . htmlspecialchars($entry['diff']) . '</td>';
                    }
                    echo '</tr>';
                    echo '</table>';
                }
                ?>
            </article>
        </section>
        <aside>
            <h2>News</h2>
            <ul>
                <li><a href="#">New1</a></li>
                <li><a href="#">New2</a></li>
                <li><a href="#">New3</a></li>
            </ul>
        </aside>
    </section>
    <footer>
        Copyright &copy; 2020
        <a href="/" rel="copyright">Localhost</a>.
        This is the module.
    </footer>
</div>
</body>
</html>