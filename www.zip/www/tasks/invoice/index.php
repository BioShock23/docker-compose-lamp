<?php
session_start();
$error = $_GET['error'] ?? '';
$success = false;
if (isset($_SESSION['success']) && $_SESSION['success'] === true) {
    $success = true;
    unset($_SESSION['success']);
}

$formData = [];
if (isset($_SESSION['form_data']) && isset($_SESSION['form_submit_flag'])) {
    $formData = $_SESSION['form_data'];
    unset($_SESSION['form_data']);
    unset($_SESSION['form_submit_flag']);
}

$cities = ['Москва', 'Санкт-Петербург'];
?>
<!DOCTYPE html>
<html lang="ru">
<header>
    <div class="header-container">
        <a class="logo-container" href="../../index.html">
            <div class="logo">
                <div class="arc arc-1"></div>
                <div class="arc arc-2"></div>
                <div class="arc arc-3"></div>
            </div>
            ergonomics
        </a>
        <nav>
            <a href="../../index.html#features">Вернуться назад</a>
        </nav>
    </div>
</header>
<head>
    <title>Заказ мебели</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="../../styles.css">
</head>
<body>
<div id="invoice-container">
    <?php if ($error): ?>
        <div id="invoice-error"><?= htmlspecialchars($error) ?></div>
    <?php endif ?>

    <h1>Заказ мебели</h1>
    <form method="post" action="generate.php" enctype="multipart/form-data">
        <div class="invoice-form-row">
            <div class="invoice-form-label">Фамилия</div>
            <div class="invoice-form-input">
                <input type="text" name="surname" required
                       value="<?= isset($formData['surname']) ? htmlspecialchars($formData['surname']) : '' ?>">
            </div>
        </div>

        <div class="invoice-form-row">
            <div class="invoice-form-label">Город доставки</div>
            <div class="invoice-form-input">
                <select name="city" required>
                    <?php foreach ($cities as $city): ?>
                        <option value="<?= htmlspecialchars($city) ?>" <?= (isset($formData['city']) && $formData['city'] === $city) ? 'selected' : '' ?>><?= htmlspecialchars($city) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="invoice-form-row">
            <div class="invoice-form-label">Дата доставки</div>
            <div class="invoice-form-input">
                <input type="date" name="delivery_date" required
                       value="<?= isset($formData['delivery_date']) ? htmlspecialchars($formData['delivery_date']) : '' ?>">
            </div>
        </div>

        <div class="invoice-form-row">
            <div class="invoice-form-label">Адрес</div>
            <div class="invoice-form-input">
                <input type="text" name="address" required
                       value="<?= isset($formData['address']) ? htmlspecialchars($formData['address']) : '' ?>">
            </div>
        </div>

        <div id="invoice-furniture-section">
            <div id="invoice-color-column">
                <div class="invoice-section-header">Выберите цвет мебели</div>
                <?php
                $colors = [
                    'Орех' => 1.1,
                    'Дуб мореный' => 1.2,
                    'Палисандр' => 1.3,
                    'Эбеновое дерево' => 1.4,
                    'Клен' => 1.5,
                    'Лиственница' => 1.6
                ];
                foreach ($colors as $name => $markup): ?>
                    <div class="invoice-radio-item">
                        <input type="radio" name="color" value="<?= $name ?>"
                               required <?= (isset($formData['color']) && $formData['color'] === $name) ? 'checked' : '' ?>> <?= $name ?>
                    </div>
                <?php endforeach ?>
            </div>

            <div id="invoice-items-column">
                <div class="invoice-section-header">Выберите предметы мебели</div>
                <?php
                $items = ['Банкетка', 'Кровать', 'Комод', 'Шкаф', 'Стул', 'Стол'];
                foreach ($items as $index => $item): ?>
                    <div class="invoice-checkbox-item">
                        <input type="checkbox" name="items[]"
                               value="<?= $item ?>" <?= (isset($formData['items']) && in_array($item, $formData['items'])) ? 'checked' : '' ?>
                               id="item_<?= $index ?>"> <?= $item ?>
                    </div>
                <?php endforeach ?>
            </div>

            <div id="invoice-quantity-column">
                <div class="invoice-section-header">Количество</div>
                <?php foreach ($items as $index => $item): ?>
                    <div class="invoice-quantity-item">
                        <input type="number" name="quantity[<?= $item ?>]" min="1"
                               value="<?= isset($formData['quantity'][$item]) ? (int)$formData['quantity'][$item] : 1 ?>">
                    </div>
                <?php endforeach ?>
            </div>
        </div>

        <div id="invoice-buttons-row">
            <div id="invoice-file-input">
                <label id="invoice-file-button">
                    Выбрать файл с ценами
                    <input type="file" name="price_file" accept=".txt" required style="display: none;"
                           id="priceFileInput">
                </label>
                <span id="invoice-file-name">price.txt</span>
                <div id="fileUploadIndicator" style="display: none; color: green; margin-top: 5px;">✓ Файл price.txt выбран
                </div>
            </div>

            <button type="submit">Оформить заказ</button>
        </div>
    </form>

    <?php if ($success && isset($_SESSION['generated_file'])): ?>
        <div id="invoice-success">
            <div id="invoice-success-message">Накладная успешно сформирована!</div>
            <div id="invoice-success-details">
                <div id="invoice-final-price">Итоговая стоимость: <?= number_format($_SESSION['total_price'], 0, '.', ' ') ?>
                    руб.
                </div>
                <a href="download.php" id="invoice-download-button">Скачать накладную</a>
            </div>
        </div>
    <?php endif ?>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const fileInput = document.getElementById('priceFileInput');
        const fileNameDisplay = document.getElementById('invoice-file-name');
        const fileIndicator = document.getElementById('fileUploadIndicator');

        fileInput.addEventListener('change', function () {
            if (this.files.length > 0) {
                fileNameDisplay.textContent = this.files[0].name;
                fileIndicator.style.display = 'block';
            } else {
                fileNameDisplay.textContent = 'price.txt';
                fileIndicator.style.display = 'none';
            }
        });
    });
</script>
</body>
<footer>
    <div class="footer-content">
        <div class="footer-section">
            <h3>О сайте</h3>
            <p>Данный сайт был свёрстан и спроектирован в рамках курса "Вёрстка и прототипирование сайтов"</p>
        </div>
        <div class="footer-section">
            <h3>ergonomics</h3>
            <ul>
                <li><a href="../../index.html#home">Главная</a></li>
                <li><a href="../../index.html#about">Об эргономике</a></li>
                <li><a href="../../index.html#devices">Устройства</a></li>
                <li><a href="../../index.html#features">Возможности</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Контакты</h3>
            <p>Email: miniahmetov.au@edu.spbstu.ru</p>
            <p>Telegram: @bioshxck</p>
        </div>
    </div>
    <p class="footer-bottom">© 2024 Arthur Miniakhmetov.</p>
</footer>
</html>