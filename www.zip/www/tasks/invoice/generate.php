<?php
require 'vendor/autoload.php';

use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$colorImages = [
    'Орех' => __DIR__ . '/assets/орех.png',
    'Дуб мореный' => __DIR__ . '/assets/дуб.png',
    'Палисандр' => __DIR__ . '/assets/палисандр.png',
    'Эбеновое дерево' => __DIR__ . '/assets/эбен.png',
    'Клен' => __DIR__ . '/assets/клен.png',
    'Лиственница' => __DIR__ . '/assets/лиственница.png'
];

$colorMarkup = [
    'Орех' => 1.1,
    'Дуб мореный' => 1.2,
    'Палисандр' => 1.3,
    'Эбеновое дерево' => 1.4,
    'Клен' => 1.5,
    'Лиственница' => 1.6
];

$tableStyle = [
    'borderSize' => 6,
    'borderColor' => '000000',
    'alignment' => 'center',
    'cellMargin' => 100,
    'width' => 100 * 50
];

$cellTextStyle = [
    'size' => 11
];

$cellStyleCenter = [
    'valign' => 'center',
    'alignment' => 'center',
    'spaceAfter' => 0
];

$cellStyleLeft = [
    'valign' => 'center',
    'alignment' => 'left',
    'spaceAfter' => 0
];

$cellStyleRight = [
    'valign' => 'center',
    'alignment' => 'right',
    'spaceAfter' => 0
];

$headerCellStyle = [
    'valign' => 'center',
    'alignment' => 'center',
    'bgColor' => 'F2F2F2'
];

$defaultParagraphStyle = [
    'spaceAfter' => 120,
    'spacing' => 120,
    'alignment' => 'left'
];

$defaultTextStyle = [
    'size' => 11,
    'spacing' => 0
];

$boldTextStyle = [
    'size' => 11,
    'bold' => true
];

$headerStyle = [
    'size' => 12,
    'bold' => true,
    'spaceAfter' => 120
];

$titleStyle = [
    'bold' => true,
    'size' => 16,
    'alignment' => 'center',
    'spaceAfter' => 240
];

$sectionStyle = array(
    'marginLeft' => 1200,
    'marginRight' => 1200,
    'marginTop' => 1200,
    'marginBottom' => 1200
);

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Неверный метод запроса");
    }

    $required = ['surname', 'city', 'delivery_date', 'address', 'color', 'items'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("Поле '$field' обязательно для заполнения");
        }
    }

    if (!isset($_FILES['price_file']) || $_FILES['price_file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("Ошибка загрузки файла прайса");
    }

    $priceFile = $_FILES['price_file']['tmp_name'];
    $prices = [];
    $content = file($priceFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach (array_slice($content, 2) as $line) {
        list($item, $price) = preg_split('/\s+/', $line);;
        $prices[$item] = (int)$price;
    }

    $selectedItems = $_POST['items'];
    $quantities = $_POST['quantity'] ?? [];
    foreach ($selectedItems as $item) {
        if (!isset($prices[$item])) {
            throw new Exception("Товар '$item' отсутствует в прайсе");
        }
        if (!isset($quantities[$item]) || $quantities[$item] < 1) {
            throw new Exception("Неверное количество для товара '$item'");
        }
    }

    $markup = $colorMarkup[$_POST['color']] ?? 1;

    $totalBeforeMarkup = 0;
    $orderItems = [];
    foreach ($selectedItems as $item) {
        $quantity = (int)$quantities[$item];
        $basePrice = $prices[$item];
        $itemTotal = $basePrice * $quantity;
        $orderItems[] = [
            'name' => $item,
            'quantity' => $quantity,
            'price' => $basePrice,
            'total' => $itemTotal
        ];
        $totalBeforeMarkup += $itemTotal;
    }

    $totalWithMarkup = $totalBeforeMarkup * $markup;

    $invoiceNumber = rand(1000, 9999);

    $phpWord = new PhpWord();

    $phpWord->setDefaultFontName('Times New Roman');
    $phpWord->setDefaultFontSize(11);

    $section = $phpWord->addSection($sectionStyle);

    $header = $section->addHeader();
    $table = $header->addTable();
    $table->addRow();
    $cell = $table->addCell(4500);
    $cell = $table->addCell(4500, ['alignment' => 'right']);
    $cell->addImage(__DIR__ . '/assets/штрих.JPG', [
        'width' => 100,
        'height' => 50,
        'alignment' => 'right'
    ]);

    $section->addText("Накладная №$invoiceNumber", $titleStyle, ['alignment' => 'center']);
    $section->addTextBreak();

    $section->addText("Адрес получения заказа: г. {$_POST['city']}, {$_POST['address']}", $defaultTextStyle);

    $deliveryDate = DateTime::createFromFormat('Y-m-d', $_POST['delivery_date']);
    $formattedDate = $deliveryDate ? $deliveryDate->format('d.m.Y') : $_POST['delivery_date'];
    $section->addText("Дата получения заказа: {$formattedDate}", $defaultTextStyle);
    $section->addTextBreak();


    $textStyleCenter = array_merge($cellTextStyle, ['alignment' => 'center']);
    $textStyleLeft = array_merge($cellTextStyle, ['alignment' => 'left']);
    $headerTextStyle = array_merge($cellTextStyle, ['bold' => true, 'alignment' => 'center']);

    $table = $section->addTable($tableStyle);

    $table->addRow(400);
    $table->addCell(500, $headerCellStyle)->addText('№', $headerTextStyle);
    $table->addCell(3000, $headerCellStyle)->addText('Наименование товара', $headerTextStyle);
    $table->addCell(1000, $headerCellStyle)->addText('Цвет', $headerTextStyle);
    $table->addCell(1200, $headerCellStyle)->addText('Цена', $headerTextStyle);
    $table->addCell(1000, $headerCellStyle)->addText('Кол-во', $headerTextStyle);
    $table->addCell(1500, $headerCellStyle)->addText('Сумма', $headerTextStyle);

    $rowIndex = 1;
    foreach ($orderItems as $item) {
        $table->addRow(400);
        $table->addCell(500, $cellStyleCenter)->addText($rowIndex++, $textStyleCenter);
        $table->addCell(3000, $cellStyleLeft)->addText($item['name'], $textStyleLeft);
        $table->addCell(1000, $cellStyleCenter)->addText('', $textStyleCenter);
        $table->addCell(1200, $cellStyleCenter)->addText(number_format($item['price'], 0, '.', ' '), $textStyleCenter);
        $table->addCell(1000, $cellStyleCenter)->addText($item['quantity'], $textStyleCenter);
        $table->addCell(1500, $cellStyleCenter)->addText(number_format($item['total'], 0, '.', ' '), $textStyleCenter);
    }

    $table->addRow(400);
    $table->addCell(500, $cellStyleCenter);
    $colorCell = $table->addCell(3000, $cellStyleLeft);
    $colorCell->addText("Цвет {$_POST['color']}", $textStyleLeft);

    $imageCell = $table->addCell(1000, $cellStyleCenter);
    $imagePath = $colorImages[$_POST['color']];
    $imageCell->addImage($imagePath, ['width' => 50, 'height' => 50, 'alignment' => 'center']);

    $markupCell = $table->addCell(2200, $cellStyleCenter);
    $markupCell->getStyle()->setGridSpan(2);
    $markupCell->addText("x$markup", $textStyleCenter);

    $table->addCell(1500, $cellStyleCenter)->addText(number_format($totalBeforeMarkup, 0, '.', ' '), $textStyleCenter);

    $table->addRow(400);
    $totalCell = $table->addCell(6700, $cellStyleRight);
    $totalCell->getStyle()->setGridSpan(5);
    $totalCell->addText('ИТОГО:', ['bold' => true, 'alignment' => 'right']);
    $table->addCell(1500, $cellStyleCenter)->addText(number_format($totalWithMarkup, 0, '.', ' '), ['bold' => true]);

    $section->addTextBreak();
    $summaryStyle = array_merge($boldTextStyle, ['spaceAfter' => 240]);
    $section->addText(
        "Всего наименований: " . count($orderItems) . ", на сумму " . number_format($totalWithMarkup, 0, '.', ' ') . " руб.",
        $summaryStyle
    );

    $section->addTextBreak();
    $warrantyFile = __DIR__ . '/assets/Гарантийное обслуживание.txt';
    $warrantyContent = file_get_contents($warrantyFile);
    $warrantyLines = explode("\n", $warrantyContent);

    $warrantyTitleStyle = array_merge($headerStyle, [
        'spaceAfter' => 180,
        'spacing' => 0,
        'size' => 12
    ]);
    $section->addText(array_shift($warrantyLines), $warrantyTitleStyle);

    $warrantyTextStyle = array_merge($defaultTextStyle, [
        'spacing' => 0,
        'spaceAfter' => 120,
        'size' => 10,
        'lineSpacing' => 1.15
    ]);

    foreach ($warrantyLines as $line) {
        $line = trim($line);
        if (!empty($line)) {
            $section->addText($line, $warrantyTextStyle);
        }
    }

    $wordFilename = "Документ_на_выдачу_$invoiceNumber.docx";
    $objWriter = IOFactory::createWriter($phpWord, 'Word2007');
    $objWriter->save($wordFilename);

    $excelFilename = 'Запись о документах.xlsx';
    $spreadsheet = null;

    if (file_exists($excelFilename)) {
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($excelFilename);
        $spreadsheet = $reader->load($excelFilename);
    } else {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', '№');
        $sheet->setCellValue('B1', 'Номер накладной');
        $sheet->setCellValue('C1', 'Город');
        $sheet->setCellValue('D1', 'Адрес');
        $sheet->setCellValue('E1', 'Сумма');
    }

    $sheet = $spreadsheet->getActiveSheet();
    $row = $sheet->getHighestRow() + 1;
    $sheet->setCellValue("A$row", $row - 1);
    $sheet->setCellValue("B$row", $invoiceNumber);
    $sheet->setCellValue("C$row", $_POST['city']);
    $sheet->setCellValue("D$row", $_POST['address']);
    $sheet->setCellValue("E$row", $totalWithMarkup);

    $writer = new Xlsx($spreadsheet);
    $writer->save($excelFilename);

    session_start();
    $_SESSION['generated_file'] = $wordFilename;
    $_SESSION['total_price'] = $totalWithMarkup;
    $_SESSION['success'] = true;

    $_SESSION['form_data'] = [
        'surname' => $_POST['surname'],
        'city' => $_POST['city'],
        'delivery_date' => $_POST['delivery_date'],
        'address' => $_POST['address'],
        'color' => $_POST['color'],
        'items' => $_POST['items'],
        'quantity' => $_POST['quantity']
    ];
    $_SESSION['form_submit_flag'] = true;

    header('Location: index.php');
    exit;

} catch (Exception $e) {
    session_start();
    $_SESSION['form_data'] = $_POST;
    $_SESSION['form_submit_flag'] = true;

    error_log($e->getMessage());
    header('Location: index.php?error=' . urlencode($e->getMessage()));
    exit;
}