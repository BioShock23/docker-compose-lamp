<?php
session_start();

if (!isset($_SESSION['generated_file'])) {
    header('Location: index.php');
    exit;
}

$filename = $_SESSION['generated_file'];

if (!file_exists($filename)) {
    header('Location: index.php?error=' . urlencode('File not found'));
    exit;
}

header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header("Content-Disposition: attachment; filename=\"$filename\"");
readfile($filename);

unlink($filename);
unset($_SESSION['generated_file']);
exit; 