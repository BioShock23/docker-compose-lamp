<?php

$name = isset($_POST['name'])
    ? trim($_POST['name'])
    : '';
$discount = isset($_POST['discount'])
    ? (int)$_POST['discount']
    : 0;
$outputMsg = '';
$imagePath = '';
$product = '';

$assembly = isset($_POST['assembly']) ? 'Сборка' : '';
$delivery = isset($_POST['delivery']) ? 'Доставка' : '';
$floor = isset($_POST['floor']) ? 'Подъём на этаж' : '';
$warranty = isset($_POST['warranty']) ? 'Гарантия' : '';

if (isset($_POST['submit_cabinet']) || isset($_POST['submit_table'])) {
    if (isset($_POST['submit_cabinet'])) {
        $product = 'Шкаф';
        $imagePath = 'img/cabinet.jpg';
    } elseif (isset($_POST['submit_table'])) {
        $product = 'Стол';
        $imagePath = 'img/table.jpg';
    }

    if ($product !== '') {
        // Чтобы убрать пустые значения
        $services = array_filter([$assembly, $delivery, $floor, $warranty]);
        $servicesString = !empty($services)
            ? implode(', ', $services)
            : 'нет дополнительных услуг';

        $outputMsg = sprintf(
            "%s, вы выбрали %s\nСкидка: %d%%\nУслуги: %s",
            $name,
            $product,
            $discount,
            $servicesString
        );
    }
}

if (isset($_POST['clear'])) {
    $name = '';
    $discount = 0;
    $assembly = '';
    $delivery = '';
    $floor = '';
    $warranty = '';
    $product = '';
    $outputMsg = '';
    $imagePath = '';
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Форма PHP</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<form method="POST" action="">

    <div class="form-row">
        <label for="name">Имя:</label>
        <input required
               pattern=".*\S+.*"
               title="Имя не может состоять из пробелов"
               type="text"
               id="name"
               name="name"
               value="<?php echo htmlspecialchars($name); ?>">

        <label for="discount">Скидка:</label>
        <input type="range"
               id="discount"
               name="discount"
               min="0" max="25"
               value="<?php echo $discount; ?>"
               oninput="document.getElementById('discountValue').textContent = this.value + '%'">
        <span id="discountValue"><?php echo $discount . '%'; ?></span>
    </div>

    <div class="checkboxes">
        <div>
            <input type="checkbox" id="assembly" name="assembly" <?php echo $assembly ? 'checked' : ''; ?>>
            <label for="assembly">Сборка</label>
        </div>
        <div>
            <input type="checkbox" id="delivery" name="delivery" <?php echo $delivery ? 'checked' : ''; ?>>
            <label for="delivery">Доставка</label>
        </div>
        <div>
            <input type="checkbox" id="floor" name="floor" <?php echo $floor ? 'checked' : ''; ?>>
            <label for="floor">Этаж</label>
        </div>
        <div>
            <input type="checkbox" id="warranty" name="warranty" <?php echo $warranty ? 'checked' : ''; ?>>
            <label for="warranty">Гарантия</label>
        </div>
    </div>

    <div class="buttons form-row">
        <button type="submit" name="submit_cabinet">Шкаф</button>
        <button type="submit" name="submit_table">Стол</button>
        <button type="submit" name="clear">Очистить</button>
    </div>

</form>

<?php if ($outputMsg !== ''): ?>
    <div class="output-container">
        <div class="output-text">
            <?php echo htmlspecialchars($outputMsg); ?>
        </div>
        <?php if ($imagePath): ?>
            <img src="<?php echo htmlspecialchars($imagePath); ?>"
                 alt="<?php echo htmlspecialchars($product); ?>"
                 class="product-image">
        <?php endif; ?>
    </div>
<?php endif; ?>

</body>
</html>
