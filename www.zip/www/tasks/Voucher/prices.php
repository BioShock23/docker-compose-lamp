<?php
return [
    'service_types' => [
        'rent' => [
            'key' => 'rent',
            'code' => 'A1',
            'price' => 100,
            'name' => 'Прокат',
            'description' => 'Прокат на несколько дней'
        ],
        'sell' => [
            'key' => 'sell',
            'code' => 'A2',
            'price' => 500,
            'name' => 'Продажа',
            'description' => 'Комиссионные услуги'
        ],
        'leasing' => [
            'key' => 'leasing',
            'code' => 'A3',
            'price' => 2100,
            'name' => 'Лизинг',
            'description' => 'Долгосрочный прокат'
        ]
    ],

    'additional_options' => [
        'leather' => [
            'key' => 'leather',
            'price' => 50,
            'label' => 'Кожаный салон',
            'description' => 'Кожа, рожа, все дела'
        ],
        'heated_seats' => [
            'key' => 'heated_seats',
            'price' => 30,
            'label' => 'Подогрев сидений',
            'description' => 'Только передние'
        ],
        'sunroof' => [
            'key' => 'sunroof',
            'price' => 100,
            'label' => 'Люк',
            'description' => 'Полностью прозрачный'
        ]
    ],

    'car_models' => [
        'rent' => [
            'Peugeot' => 200,
            'Lada' => 100,
            'Nissan' => 300
        ],
        'sell' => [
            'Citroen' => 500,
            'Skoda' => 300,
            'Lexus' => 800
        ],
        'leasing' => [
            'Kia' => 50,
            'Honda' => 100,
            'Mazda' => 80
        ]
    ],

    'preparations' => [
        'rent' => [
            'fuel' => ['key' => 'fuel', 'name' => 'Бензин', 'price' => 50],
            'tires' => ['key' => 'tires', 'name' => 'Шины', 'price' => 100],
            'windscreen' => ['key' => 'windscreen', 'name' => 'Омыватель', 'price' => 200]
        ],
        'sell' => [
            'polishing' => ['key' => 'polishing', 'name' => 'Полировка', 'price' => 100],
            'cleaning' => ['key' => 'cleaning', 'name' => 'Чистка салона', 'price' => 50],
            'inspection' => ['key' => 'inspection', 'name' => 'ТО', 'price' => 200]
        ],
        'leasing' => [
            'fuel' => ['key' => 'fuel', 'name' => 'Бензин', 'price' => 50],
            'cleaning' => ['key' => 'cleaning', 'name' => 'Чистка салона', 'price' => 200],
            'engine' => ['key' => 'engine', 'name' => 'Чистка двигателя', 'price' => 100]
        ]
    ]
];