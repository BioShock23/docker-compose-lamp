<?php

session_start();

if (!isset($_SESSION['order_data'], $_SESSION['bill_data'], $_SESSION['invoice_number'])) {
    header('Location: pages/order.php');
    exit;
}

set_time_limit(30);

$prices = require __DIR__ . '/prices.php';
require __DIR__ . '/price_calculator.php';

$order = $_SESSION['order_data'];
$bill = $_SESSION['bill_data'];
$service = $order['service_type'];
$totals = calculateInvoiceTotals($order, $bill, $prices);

$serviceImages = [
    'rent' => 'http://arturmzj.beget.tech/tasks/Voucher/images/task/rental.jpeg',
    'sell' => 'http://arturmzj.beget.tech/tasks/Voucher/images/task/sale.jpg',
    'leasing' => 'http://arturmzj.beget.tech/tasks/Voucher/images/task/leasing.jpg'
];

$htmlContent = "
    <html>
    <body style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
        <div style='text-align: center; margin-bottom: 20px;'>
            <h2 style='font-weight: normal;'>Уважаемый {$order['name']}!</h2>
        </div>
        
        <div style='display: flex;'>
            <div style='flex: 1;'>
                <p>Наш автосалон рад предложить Вам услугу <strong>{$service['name']} автомобиля {$bill['car_model']}</strong>.</p>
                <p>Количество дней: {$bill['days']}</p>
                <p>Дополнительные опции:</p>
                <ul style='list-style-type: none; padding-left: 20px;'>
";

foreach ($order['options'] as $option) {
    $htmlContent .= "<li>• {$option['label']}</li>";
}

$htmlContent .= "
                </ul>
                
                <p style='margin-top: 30px;'><strong>Полная стоимость заключенного контракта: {$totals['full_total']} руб.</strong></p>
            </div>
            
            <div style='flex: 0 0 250px; text-align: right;'>
                <img src='{$serviceImages[$service['key']]}' alt='Service Type' style='max-width: 100%; border-radius: 5px;'>
            </div>
        </div>
    </body>
    </html>
";

$plainTextContent = "Уважаемый {$order['name']}!\n\n";
$plainTextContent .= "Наш автосалон рад предложить Вам услугу {$service['name']} автомобиля {$bill['car_model']}.\n";
$plainTextContent .= "Количество дней: {$bill['days']}\n";
$plainTextContent .= "Дополнительные опции:\n";

foreach ($order['options'] as $option) {
    $plainTextContent .= "• {$option['label']}\n";
}

$plainTextContent .= "\nПолная стоимость заключенного контракта: {$totals['full_total']} руб.";

$headers = array(
    'MIME-Version: 1.0',
    'Content-type: text/html; charset=utf-8',
    'From: ООО "Тарантайка" <tarantayka@arturmzj.beget.tech>',
    'Reply-To: tarantayka@arturmzj.beget.tech',
    'X-Mailer: PHP/' . phpversion()
);

$mailSent = mail(
    $order['email'],
    'Подтверждение заказа - Счет №' . $_SESSION['invoice_number'],
    $htmlContent,
    implode("\r\n", $headers)
);

if ($mailSent) {
    $_SESSION['email_status'] = 'Письмо успешно отправлено!';
} else {
    $_SESSION['email_status'] = "Не удалось отправить письмо.";
}

header('Location: pages/basket.php');
exit;