<?php
session_start();

// Authentication check
if (!isset($_COOKIE['auth'])) {
    header('Location: ../index.php');
    exit;
}

require_once __DIR__ . '/../price_calculator.php';
$prices = require_once __DIR__ . '/../prices.php';

$servicePrices = $prices['service_types'];
$additionalOptions = $prices['additional_options'];
$carModels = $prices['car_models'];
$preparations = $prices['preparations'];

// Redirect if no session data
if (!isset($_SESSION['order_data']) || !isset($_SESSION['bill_data'])) {
    header('Location: order.php');
    exit;
}

$orderData = $_SESSION['order_data'];
$billData = $_SESSION['bill_data'];
$serviceType = $orderData['service_type'];

// Calculate total price
$total = calculateInvoiceTotals($_SESSION['order_data'], $_SESSION['bill_data'], $prices)['full_total'];

// Generate and store invoice number if not exists
if (!isset($_SESSION['invoice_number'])) {
    $_SESSION['invoice_number'] = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
}

// Service type images (URLs relative to this file)
$serviceImages = [
    'rent' => '../images/task/rental.jpeg',
    'sell' => '../images/task/sale.jpg',
    'leasing' => '../images/task/leasing.jpg'
];
?>
<html>
<head>
    <title>Корзина</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
</head>

<body topmargin="0" bottommargin="0" rightmargin="0" leftmargin="0" background="../images/back_main.gif">
<table cellpadding="0" cellspacing="0" border="0" align="center" width="583" height="614">
    <tr>
        <td valign="top" width="583" height="208" background="../images/row1.gif">
            <div style="margin-left:88px; margin-top:57px "><img src="../images/w1.gif">    </div>
            <div style="margin-left:50px; margin-top:69px ">
                <a href="../index.php">Главная<img src="../images/m1.gif" border="0" ></a>
                <img src="../images/spacer.gif" width="20" height="10">
                <a href="order.php">Заказ<img src="../images/m2.gif" border="0" ></a>
                <img src="../images/spacer.gif" width="5" height="10">
                <a href="basket.php">Корзина<img src="../images/m3.gif" border="0" ></a>
                <img src="../images/spacer.gif" width="5" height="10">
                <a href="index-3.php">О компании<img src="../images/m4.gif" border="0" ></a>
                <img src="../images/spacer.gif" width="5" height="10">
                <a href="index-4.php">Контакты<img src="../images/m5.gif" border="0" ></a>
                </form>
            </div>
        </td>
    </tr>
    <tr>
        <td valign="top" width="583" height="338" bgcolor="#FFFFFF">
            <table cellpadding="0" cellspacing="0" border="0">
                <tr>
                    <td valign="top" height="338" width="42"></td>
                    <td valign="top" height="338" width="492">
                        <table cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td width="492" valign="top" height="106">
                                    <div style="margin-left:1px; margin-top:2px; margin-right:10px ">
                                        <div style="margin-left:5px "><img src="../images/1_p1.gif" align="left"></div>
                                        <div style="margin-left:95px "><font class="title">Детали заказа</font><br>
                                            <img src="<?= $serviceImages[$serviceType['key']] ?>" alt="Тип услуги" width="100">
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td width="492" valign="top" height="232">
                                    <table cellpadding="0" cellspacing="0" border="0">
                                        <tr>
                                            <td valign="top" height="232" width="248">
                                                <div style="margin-left:6px; margin-top:2px; "><img src="../images/hl.gif"></div>
                                                <div style="margin-left:6px; margin-top:7px; ">
                                                    <strong>Детали услуги:</strong><br>
                                                    Тип: <?= $serviceType['name'] ?> (<?= $servicePrices[$serviceType['key']]['price'] ?>р.)<br>
                                                    Модель: <?= $billData['car_model'] ?> (+<?= $carModels[$serviceType['key']][$billData['car_model']] ?>р.)<br>

                                                    Доп. опции:<br>
                                                    <?php foreach ($orderData['options'] as $option): ?>
                                                        - <?= $option['label'] ?> (+<?= $option['price'] ?>р.)<br>
                                                    <?php endforeach; ?>

                                                    Подготовка:<br>
                                                    <?php foreach ($billData['preparations'] ?? [] as $prep): ?>
                                                        - <?= $prep['name']?> (+<?= $prep['price'] ?>р.)<br>
                                                    <?php endforeach; ?>

                                                    <?php if (in_array($serviceType['key'], ['rent', 'leasing'])): ?>
                                                        Дней: <?= $billData['days'] ?><br>
                                                    <?php else: ?>
                                                        <?= isset($billData['fast_registration']) ? 'Ускоренная продажа' : '' ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td valign="top" height="215" width="1" background="../images/tal.gif"></td>
                                            <td valign="top" height="215" width="243">
                                                <div style="margin-left:22px; margin-top:13px; ">
                                                    <strong>Итого:</strong><br>
                                                    <?= $total ?>р.<br><br>
                                                    <form action="../mail_sender.php" method="post">
                                                        <button type="submit" name="send_email">
                                                            <?php if (isset($_SESSION['email_status'])): ?>
                                                                <?= $_SESSION['email_status'] ?>
                                                            <?php else: ?>
                                                                Отправить на email
                                                            <?php endif; ?>
                                                        </button>
                                                    </form>
                                                    <br>
                                                    <form action="download_invoice.php" method="post">
                                                        <button type="submit">Скачать файл</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td valign="top" width="583" height="68" background="../images/row3.gif">
            <div style="margin-left:51px; margin-top:31px ">
                <a href="#"><img src="../images/p1.gif" border="0"></a>
                <img src="../images/spacer.gif" width="26" height="9">
                <a href="#"><img src="../images/p2.gif" border="0"></a>
                <img src="../images/spacer.gif" width="30" height="9">
                <a href="#"><img src="../images/p3.gif" border="0"></a>
                <img src="../images/spacer.gif" width="149" height="9">
                <a href="index-5.php"><img src="../images/copyright.gif" border="0"></a>
            </div>
        </td>
    </tr>
</table>
</body>
</html>