<?php
require '../vendor/autoload.php';
require __DIR__ . '/../price_calculator.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Border;

session_start();

if (!isset($_SESSION['order_data']) || !isset($_SESSION['bill_data']) || !isset($_SESSION['invoice_number'])) {
    header('Location: order.php');
    exit;
}

$order = $_SESSION['order_data'];
$bill = $_SESSION['bill_data'];
$serviceType = $order['service_type'];

$prices = require __DIR__ . '/../prices.php';

$modelPrice = $prices['car_models'][$serviceType['key']][$bill['car_model']];

$totals = calculateInvoiceTotals($order, $bill, $prices);

$subtotal = $totals['base_total'];
$total = $totals['full_total'];

$invoiceNumber = $_SESSION['invoice_number'];

$replacements = [
    '{ORGANIZATION}' => 'Тарантайка',
    '{INVOICE_NUMBER}' => $invoiceNumber,
    '{CUSTOMER_NAME}' => $order['name'],
    '{CUSTOMER_PHONE}' => $order['phone'],
    '{CUSTOMER_EMAIL}' => $order['email'],
    '{SERVICE_TYPE}' => $serviceType['name'],
    '{BASE_TOTAL}' => $totals['base_total'],
    '{CAR_MODEL}' => $bill['car_model'],
    '{DAYS_USED}' => in_array($serviceType['key'], ['rent', 'leasing']) ? $totals['days_used'] : 0,
    '{SUBTOTAL}' => in_array($serviceType['key'], ['rent', 'leasing']) ? $subtotal : 0,
    '{TOTAL}' => $total,
    '{DATE}' => date('d.m.Y'),
    '{MANAGER_NAME}' => 'Миниахметов А.У',
    '{CAR_MARKUP}' => $modelPrice,
    '{SERVICE_CODE}' => $serviceType['code']
];

$templatePath = __DIR__ . '/../template.xlsx';
$spreadsheet = IOFactory::load($templatePath);
$sheet = $spreadsheet->getActiveSheet();

foreach ($sheet->getRowIterator() as $row) {
    foreach ($row->getCellIterator() as $cell) {
        $value = $cell->getValue();
        if (is_string($value)) {
            foreach ($replacements as $placeholder => $replacement) {
                if (strpos($value, $placeholder) !== false) {
                    $cell->setValue(str_replace($placeholder, $replacement, $value));
                }
            }
        }
    }
}

function applyTableBorders($sheet, $row) {
    $sheet->getStyle("A$row:D$row")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
}

$row = 18;
$counter = 3;
foreach ($bill['preparations'] as $preparation) {
    $sheet->setCellValue("A$row", $counter);
    $sheet->setCellValue("B$row", $preparation['name']);
    $sheet->setCellValue("D$row", $preparation['price']);
    applyTableBorders($sheet, $row);
    $row++;
    $counter++;
}

$row = 23;
$counter = 1;
foreach ($order['options'] as $option) {
    $sheet->setCellValue("A$row", $counter);
    $sheet->setCellValue("B$row", $option['label']);
    $sheet->setCellValue("D$row", $option['price']);
    applyTableBorders($sheet, $row);
    $row++;
    $counter++;
}

applyTableBorders($sheet, 15); // "Предварительная подготовка"
applyTableBorders($sheet, 22); // "Стоимость доп. опций"

$spreadsheet->getProperties()->setTitle("Накладная №$invoiceNumber");

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$order['name'].'_'.date('d.m.Y').'.xlsx"');
header('Cache-Control: max-age=0');

$writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
$writer->save('php://output');
exit;