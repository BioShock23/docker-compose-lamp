<?php
session_start();

// Authentication check
if (!isset($_COOKIE['auth'])) {
    header('Location: ../index.php');
    exit;
}

$prices = require_once __DIR__ . '/../prices.php';

$carModels = $prices['car_models'];
$preparations = $prices['preparations'];

// Redirect if no session data
if (!isset($_SESSION['order_data'])) {
    header('Location: order.php');
    exit;
}


$orderData = $_SESSION['order_data'];
$serviceType = $orderData['service_type'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $_SESSION['bill_data'] = [
        'car_model' => $_POST['car_model'],
        'preparations' => array_map(
            fn($key) => $prices['preparations'][$serviceType['key']][$key],
            $_POST['preparations'] ?? array_keys($prices['preparations'][$serviceType['key']])
        ),
        'days' => $_POST['days'] ?? null,
        'fast_registration' => isset($_POST['fast_registration'])
    ];
    
    header('Location: basket.php');
    exit;
}

// Dynamic content based on service type
$showDaysField = in_array($serviceType['key'], ['rent', 'leasing']);
$defaultPreparations = array_keys($prices['preparations'][$serviceType['key']]);

?>
<html>
<head>
    <title>Работа</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
</head>

<body topmargin="0" bottommargin="0" rightmargin="0" leftmargin="0" background="../images/back_main.gif">
<form method="post">
    <table cellpadding="0" cellspacing="0" border="0" align="center" width="583" height="614">
        <tr>
            <td valign="top" width="583" height="208" background="../images/row1.gif">
                <div style="margin-left:88px; margin-top:57px "><img src="../images/w1.gif"></div>
                <div style="margin-left:50px; margin-top:69px ">
                    <a href="../index.php">Главная<img src="../images/m1.gif" border="0"></a>
                    <img src="../images/spacer.gif" width="20" height="10">
                    <a href="order.php">Заказ<img src="../images/m2.gif" border="0"></a>
                    <img src="../images/spacer.gif" width="5" height="10">
                    <a href="basket.php">Корзина<img src="../images/m3.gif" border="0"></a>
                    <img src="../images/spacer.gif" width="5" height="10">
                    <a href="index-3.php">О компании<img src="../images/m4.gif" border="0"></a>
                    <img src="../images/spacer.gif" width="5" height="10">
                    <a href="index-4.php">Контакты<img src="../images/m5.gif" border="0"></a>
                </div>
            </td>
        </tr>
        <tr>
            <td valign="top" width="583" height="338" bgcolor="#FFFFFF">
                <table cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td valign="top" height="338" width="42"></td>
                        <td valign="top" height="338" width="492">
                            <table cellpadding="0" cellspacing="0" border="0">
                                <tr>
                                    <td width="492" valign="top" height="106">
                                        <div style="margin-left:1px; margin-top:2px; margin-right:10px ">
                                            <div style="margin-left:95px ">
                                                <!-- 2-1: Car Models -->
                                                <h4>Выберите модель:</h4>
                                                <div class="models">
                                                    <?php 
                                                    $first = true;
                                                    foreach ($carModels[$serviceType['key']] as $model => $price): 
                                                    ?>
                                                        <label>
                                                            <input type="radio" name="car_model" value="<?= $model ?>" 
                                                                <?= $first ? 'checked' : '' ?> required>
                                                            <?= $model ?> (+<?= $price ?>)
                                                        </label>
                                                    <?php 
                                                    $first = false;
                                                    endforeach; 
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="492" valign="top" height="232">
                                        <table cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                <td valign="top" height="232" width="248">
                                                    <!-- 2-2: Preparations -->
                                                    <h4>Подготовка:</h4>
                                                    <div class="preparations">
                                                        <?php foreach ($preparations[$serviceType['key']] as $key => $prep): ?>
                                                            <label>
                                                                <input type="checkbox" name="preparations[]" value="<?= $key ?>" checked>
                                                                <?= $prep['name'] ?> (+<?= $prep['price'] ?>)
                                                            </label><br>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </td>
                                                <td valign="top" height="215" width="1"
                                                    background="../images/tal.gif"></td>
                                                <td valign="top" height="215" width="243">
                                                    <!-- 2-3: Conditional Fields -->
                                                    <?php if ($showDaysField): ?>
                                                        <h4>Количество дней:</h4>
                                                        <input type="number" name="days" min="1" required>
                                                    <?php else: ?>
                                                        <label>
                                                            <input type="checkbox" name="fast_registration" checked>
                                                            Ускоренная продажа
                                                        </label>
                                                    <?php endif; ?>
                                                    <!-- 2-4: Buttons -->
                                                    <div style="margin-top: 20px;">
                                                        <button type="button" onclick="window.location.href='order.php'">Назад</button>
                                                        <button type="submit">Продолжить</button>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td valign="top" width="583" height="68" background="../images/row3.gif">
                <div style="margin-left:51px; margin-top:31px ">
                    <a href="#"><img src="../images/p1.gif" border="0"></a>
                    <img src="../images/spacer.gif" width="26" height="9">
                    <a href="#"><img src="../images/p2.gif" border="0"></a>
                    <img src="../images/spacer.gif" width="30" height="9">
                    <a href="#"><img src="../images/p3.gif" border="0"></a>
                    <img src="../images/spacer.gif" width="149" height="9">
                    <a href="index-5.php"><img src="../images/copyright.gif" border="0"></a>
                </div>
            </td>
        </tr>    </table>
</form>
</body>
</html>
