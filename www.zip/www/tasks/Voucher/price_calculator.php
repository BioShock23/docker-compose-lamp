<?php
function calculateInvoiceTotals($orderData, $billData, $prices): array
{
    $serviceType = $orderData['service_type'];

    $basePrice = $serviceType['price'];
    $carPrice = !empty($billData['car_model']) ? 
        $prices['car_models'][$serviceType['key']][$billData['car_model']] : 0;

    $optionsPrice = array_sum(array_map(
        fn($option) => $option['price'],
        $orderData['options'] ?? []
    ));

    $preparationsPrice = array_sum(
        array_map(fn($prep) => $prep['price'], $billData['preparations'] ?? [])
    );

    $days = $billData['days'] ?? 0;
    $isTemporalService = in_array($serviceType['key'], ['rent', 'leasing']);

    $baseTotal = ($basePrice + $carPrice) * ($isTemporalService ? max($days, 1) : 1);

    $fullDays = $isTemporalService ? max($days, 1) : 1;
    $fullTotal = ($basePrice + $carPrice) * $fullDays + $optionsPrice + $preparationsPrice;

    return [
        'base_total' => $baseTotal,
        'full_total' => $fullTotal,
        'days_used' => $fullDays,
        'options_price' => $optionsPrice,
        'preparations_price' => $preparationsPrice
    ];
}